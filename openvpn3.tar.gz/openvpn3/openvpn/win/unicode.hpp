//    OpenVPN -- An application to securely tunnel IP networks
//               over a single port, with support for SSL/TLS-based
//               session authentication and key exchange,
//               packet encryption, packet authentication, and
//               packet compression.
//
//    Copyright (C) 2013-2014 OpenVPN Technologies, Inc.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU Affero General Public License Version 3
//    as published by the Free Software Foundation.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU Affero General Public License for more details.
//
//    You should have received a copy of the GNU Affero General Public License
//    along with this program in the COPYING file.
//    If not, see <http://www.gnu.org/licenses/>.

#ifndef OPENVPN_WIN_UNICODE_H
#define OPENVPN_WIN_UNICODE_H

#include <string>

#include <windows.h>

#include <openvpn/common/types.hpp>
#include <openvpn/common/exception.hpp>
#include <openvpn/common/scoped_ptr.hpp>

namespace openvpn {
  namespace Win {
    typedef ScopedPtr<wchar_t, PtrArrayFree> UTF16;

    OPENVPN_SIMPLE_EXCEPTION(win_utf16);

    inline wchar_t* utf16(const std::string& str)
    {
      // first get output length (return value includes space for trailing nul)
      const int len = MultiByteToWideChar(CP_UTF8,
					  0,
					  str.c_str(),
					  -1,
					  NULL,
					  0);
      if (len <= 0)
	throw win_utf16();
      UTF16 ret(new wchar_t[len]);
      const int len2 = MultiByteToWideChar(CP_UTF8,
					   0,
					   str.c_str(),
					   -1,
					   ret(),
					   len);
      if (len != len2)
	throw win_utf16();
      return ret.release();
    }

    inline size_t utf16_strlen(const wchar_t *str)
    {
      return wcslen(str);
    }
  }
}
#endif
