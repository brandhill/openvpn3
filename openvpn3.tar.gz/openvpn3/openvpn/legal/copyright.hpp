#ifndef OPENVPN_LEGAL_COPYRIGHT_H
#define OPENVPN_LEGAL_COPYRIGHT_H

// Define copyright strings

const char openvpn_copyright[] = "Copyright (c) 2012-2014 OpenVPN Technologies, Inc. All rights reserved."; // CONST GLOBAL

#endif
